````markdown
# 🛡️ Reconnaissance & Vulnerability Scanning

<div align="center">

![Cybersecurity](https://img.shields.io/badge/Cybersecurity-Project-blue?style=for-the-badge&logo=hackthebox)
![BlackArch](https://img.shields.io/badge/Platform-BlackArch-black?style=for-the-badge&logo=linux)
![Nmap](https://img.shields.io/badge/Tool-Nmap-red?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Completed-success?style=for-the-badge)

### 🚀 Active Reconnaissance & Vulnerability Assessment using BlackArch Linux

</div>

---

# 📌 Project Overview

This project demonstrates **Active Reconnaissance** and **Vulnerability Scanning** on a safe local network using professional cybersecurity tools.

The assessment was performed using:

- 🛰️ Network Discovery
- 🔍 Port & Service Enumeration
- 🛡️ Vulnerability Analysis
- 📡 OS Fingerprinting
- 📑 Security Risk Documentation

This project was completed as part of the **Cybersecurity Internship Program** at <a href="https://www.alfidotech.com">Alfido Tech</a>.

---

# 🎯 Objective

✅ Discover active hosts in the network  
✅ Enumerate open ports and running services  
✅ Detect operating systems and service versions  
✅ Analyze potential security risks  
✅ Document findings professionally  

---

# 🛠️ Tools & Technologies Used

| 🧰 Tool | 📌 Purpose |
|---|---|
| BlackArch Linux | Penetration Testing Environment |
| Nmap | Port & Service Enumeration |
| arp-scan | Host Discovery |
| Nikto | Web Vulnerability Scanning |
| Linux Terminal | Reconnaissance Operations |

---

# 🌐 Network Information

| 🔧 Parameter | 📄 Value |
|---|---|
| Local IP Address | `10.99.227.2` |
| Network Interface | `wlan0` |
| Network Range | `10.99.227.0/24` |

---

# 🔍 Phase 1 — Host Discovery

## 📡 Command Used

```bash
arp-scan --localnet
````

## 📋 Hosts Discovered

| 🖥️ IP Address  | 📶 Status |
| --------------- | --------- |
| `10.99.227.122` | ✅ Active  |
| `10.99.227.157` | ✅ Active  |

---

# 🚪 Phase 2 — Port Scanning

# 🎯 Target: `10.99.227.122`

## 🔎 Basic Scan

```bash
nmap 10.99.227.122
```

### 📌 Output

```text
PORT   STATE SERVICE
53/tcp open  domain
```

---

# ⚡ Service Version Detection

## 🧪 Command

```bash
sudo nmap -sV 10.99.227.122
```

### 📌 Output

```text
PORT   STATE SERVICE VERSION
53/tcp open  domain  dnsmasq 2.51
```

---

# 🛰️ Aggressive Scan

## ⚙️ Command

```bash
sudo nmap -A 10.99.227.122
```

### 📌 Findings

```text
Device type: Phone
Running: Android 9 - 11
Service: dnsmasq 2.51
```

---

# 📊 Scan Analysis

| 🔍 Attribute     | 📄 Information |
| ---------------- | -------------- |
| Open Port        | `53/tcp`       |
| Service          | DNS            |
| Version          | dnsmasq 2.51   |
| Device Type      | Android Device |
| Operating System | Android 9–11   |

---

# 🛡️ Vulnerability Findings

| ⚠️ Severity | 🔍 Finding               | 📌 Description                             |
| ----------- | ------------------------ | ------------------------------------------ |
| 🟠 Medium   | Open DNS Service         | DNS service exposed publicly               |
| 🟡 Low      | Outdated dnsmasq Version | Older software may contain vulnerabilities |
| 🔵 Info     | OS Detection Enabled     | Android OS fingerprint detected            |

---

# 🔒 Security Risks

🚨 Potential risks identified during assessment:

* DNS Enumeration Attacks
* Information Disclosure
* Service Fingerprinting
* Exploitation of outdated software
* Network Mapping Exposure

---

# ✅ Recommendations

✔️ Restrict unnecessary DNS exposure
✔️ Update dnsmasq to latest secure version
✔️ Enable firewall filtering
✔️ Disable unused services
✔️ Perform regular vulnerability assessments

---

# 📂 Project Structure

```text
Reconnaissance-Vulnerability-Scanning/
│
├── README.md
├── reconnaissance_report.txt
├── screenshots/
│   ├── arp-scan.png
│   ├── nmap-basic.png
│   ├── nmap-service-scan.png
│   └── nmap-aggressive-scan.png
```

---

# 📸 Screenshots

## 🖼️ Required Screenshots

📷 `ip a`
📷 `arp-scan --localnet`
📷 `nmap 10.99.227.122`
📷 `sudo nmap -sV 10.99.227.122`
📷 `sudo nmap -A 10.99.227.122`

---

# 💻 Commands Used

```bash
ip a

arp-scan --localnet

nmap 10.99.227.122

nmap 10.99.227.157

sudo nmap -sV 10.99.227.122

sudo nmap -sV 10.99.227.157

sudo nmap -A 10.99.227.122

sudo nmap -A 10.99.227.122 -oN reconnaissance_report.txt
```

---

# 📚 Learning Outcomes

✨ Learned active reconnaissance techniques
✨ Understood network enumeration
✨ Performed service detection
✨ Explored OS fingerprinting
✨ Analyzed cybersecurity risks
✨ Documented professional vulnerability reports

---

# 👨‍💻 Author

<div align="center">

## 🚀 Neeraj Upadhayay

🎓 B.Tech CSE Student
🛡️ Cybersecurity Enthusiast
💻 Ethical Hacking Learner

### 🌐 Connect With Me

<a href="https://github.com/Neeraj29118">GitHub</a> • <a href="https://www.linkedin.com/in/neeraj-upadhayay-2nd-a0958a246">LinkedIn</a>

</div>

---

# 🏢 Internship Information

This project was completed during the **Cybersecurity Internship Program** at <a href="https://www.alfidotech.com">Alfido Tech</a>.

---

<div align="center">

## ⭐ If you found this project useful, give it a star ⭐

</div>
```
