# Web Application Security Basics – DVWA on BlackArch

## 📌 Project Overview

This project demonstrates basic web application security testing using:

* DVWA
* Burp Suite
* BlackArch Linux
* Apache
* MariaDB
* PHP

The objective is to identify and understand common web vulnerabilities in a safe lab environment.

---

# 🎯 Goals

* Perform **Reflected XSS**
* Perform **Stored XSS**
* Perform **SQL Injection**
* Intercept HTTP requests using Burp Suite
* Learn mitigation techniques
* Practice ethical web application testing

---

# 🛠 Technologies Used

| Tool            | Purpose                |
| --------------- | ---------------------- |
| BlackArch Linux | Penetration Testing OS |
| Apache          | Web Server             |
| MariaDB         | Database               |
| PHP             | Backend Language       |
| DVWA            | Vulnerable Web App     |
| Burp Suite      | Request Interception   |

---

# ⚠️ Disclaimer

This project is created only for **educational and ethical testing purposes** inside a safe local lab environment.

Do NOT test real websites without authorization.

---

# 📂 Project Structure

```bash
DVWA/
├── config/
├── vulnerabilities/
├── hackable/
├── external/
└── index.php
```

---

# 🚀 Installation on BlackArch

## 1️⃣ Update System

```bash
sudo pacman -Syu
```

---

## 2️⃣ Install Required Packages

```bash
sudo pacman -S apache php php-apache mariadb git unzip burpsuite
```

---

# 🔧 Configure Apache + PHP

Open Apache config:

```bash
sudo nano /etc/httpd/conf/httpd.conf
```

Comment this line:

```apache
#LoadModule mpm_event_module modules/mod_mpm_event.so
```

Add these lines:

```apache
LoadModule mpm_prefork_module modules/mod_mpm_prefork.so
LoadModule php_module modules/libphp.so
AddHandler php-script .php
Include conf/extra/php_module.conf
```

Restart Apache:

```bash
sudo systemctl restart httpd
```

---

# 🗄 Setup MariaDB

Start MariaDB:

```bash
sudo systemctl enable mariadb
sudo systemctl start mariadb
```

Secure installation:

```bash
sudo mariadb-secure-installation
```

Create database:

```bash
sudo mysql
```

Inside MariaDB:

```sql
CREATE DATABASE dvwa;
EXIT;
```

---

# 📥 Install DVWA

```bash
cd /srv/http
sudo git clone https://github.com/digininja/DVWA.git
```

---

# ⚙️ Configure DVWA

Go to config directory:

```bash
cd /srv/http/DVWA/config
```

Copy config:

```bash
sudo cp config.inc.php.dist config.inc.php
```

Edit config:

```bash
sudo nano config.inc.php
```

Update database password:

```php
$_DVWA[ 'db_password' ] = 'your_password';
```

---

# 🔐 Permissions

```bash
sudo chown -R http:http /srv/http/DVWA
sudo chmod -R 755 /srv/http/DVWA
sudo chmod -R 777 /srv/http/DVWA/hackable/uploads
sudo chmod -R 777 /srv/http/DVWA/config
```

---

# ▶️ Start Services

```bash
sudo systemctl restart mariadb
sudo systemctl restart httpd
```

---

# 🌐 Open DVWA

```text
http://localhost/DVWA
```

Default credentials:

```text
Username: admin
Password: password
```

---

# 🔽 Set DVWA Security Level

Navigate to:

```text
DVWA Security → Low
```

---

# 🧪 Vulnerability Testing

# 1️⃣ Reflected XSS

URL:

```text
http://localhost/DVWA/vulnerabilities/xss_r/
```

Payload:

```html
<script>alert('XSS')</script>
```

Expected Result:

✅ JavaScript popup appears.

---

# 2️⃣ Stored XSS

URL:

```text
http://localhost/DVWA/vulnerabilities/xss_s/
```

Payload:

```html
<script>alert('Stored XSS')</script>
```

Expected Result:

✅ Payload stored and executed after refresh.

---

# 3️⃣ SQL Injection

URL:

```text
http://localhost/DVWA/vulnerabilities/sqli/
```

Payload:

```sql
1' OR '1'='1
```

Expected Result:

✅ Multiple records displayed.

---

# 🕷 Burp Suite Configuration

Start Burp Suite:

```bash
burpsuite
```

Configure Firefox proxy:

```text
IP: 127.0.0.1
Port: 8080
```

Enable:

```text
Proxy → Intercept → ON
```

Now intercept requests while performing XSS/SQLi testing.

---

# 📸 Suggested Screenshots

* DVWA Login Page
* Burp Suite Intercept
* Reflected XSS Popup
* Stored XSS Popup
* SQL Injection Result
* Captured HTTP Request

---

# 🛡 Mitigation Techniques

## Prevent XSS

* Input validation
* Output encoding
* Content Security Policy (CSP)
* Sanitization libraries

---

## Prevent SQL Injection

* Prepared Statements
* Parameterized Queries
* Input Validation
* Least Privilege Principle

Example:

```php
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$id]);
```

---

# 🔍 Useful Commands

Restart Apache:

```bash
sudo systemctl restart httpd
```

Restart MariaDB:

```bash
sudo systemctl restart mariadb
```

Check Apache Status:

```bash
sudo systemctl status httpd
```

Check Apache Logs:

```bash
sudo journalctl -xeu httpd
```

---

# 📚 Learning Outcomes

After completing this project, you will understand:

* Basics of Web Security Testing
* How XSS works
* How SQL Injection works
* HTTP Request Interception
* Web Security Best Practices

---

# 👨‍💻 Author

## Neeraj Upadhayay

* B.Tech CSE Student
* Cybersecurity Enthusiast
* BlackArch Linux User

# ⭐ Support

If you found this project helpful:

* Star the repository
* Fork the project
* Share with others

---

# 📄 License

This project is for educational purposes only.
