# Incident Response Report

## Incident Summary
A suspicious brute-force login attack was detected on the target Windows system. The attacker successfully logged in and executed malicious PowerShell commands.

---

## Timeline of Events

| Time | Event |
|------|------|
| 10:15 | Failed login attempt |
| 10:16 | Failed login attempt |
| 10:17 | Successful administrator login |
| 10:18 | Encoded PowerShell execution |
| 10:20 | Malware file created |
| 10:21 | Reverse shell connection established |
| 10:23 | Unauthorized user account created |
| 10:25 | Antivirus disabled |

---

## Indicators of Compromise (IOCs)

### Suspicious IP Addresses
- 185.243.115.84
- 45.77.88.190

### Malicious File
- C:\Windows\Temp\malware.exe

### Suspicious User
- hackeradmin

### Malicious Activities
- Encoded PowerShell command execution
- Reverse shell communication on port 4444
- Antivirus tampering

---

## Analysis

The attacker performed brute-force login attempts against the administrator account. After successful authentication, PowerShell was used to execute encoded commands. Malware was dropped into the Windows Temp directory and an outbound reverse shell connection was established.

The attacker then created a persistence account named "hackeradmin" and disabled antivirus protection.

---

## Containment Actions

- Blocked malicious IP address
- Terminated suspicious network connections
- Quarantined malware sample
- Recommended password reset for compromised accounts
- Suggested full antivirus scan

---

## Recommendations

- Enable multi-factor authentication (MFA)
- Restrict PowerShell execution policies
- Monitor failed login attempts
- Use SIEM monitoring
- Apply endpoint detection and response (EDR)

---

## Incident Severity
HIGH

---

## Status
Contained
