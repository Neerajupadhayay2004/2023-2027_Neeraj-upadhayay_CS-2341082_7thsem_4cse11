# Incident Response Simulation

## 📌 Project Overview

This project simulates a real-world cybersecurity incident response scenario using BlackArch Linux terminal tools.

The objective is to investigate suspicious Windows security logs, identify Indicators of Compromise (IOCs), perform containment actions, and generate a professional incident response report.

---

# 🎯 Objectives

* Analyze suspicious Windows log activity
* Detect Indicators of Compromise (IOCs)
* Simulate incident response procedures
* Perform containment actions
* Generate incident documentation
* Practice SOC analyst workflow

---

# 🛠️ Technologies & Tools Used

| Tool            | Purpose                      |
| --------------- | ---------------------------- |
| BlackArch Linux | Security Testing Environment |
| grep            | Log Analysis                 |
| nano            | File Editing                 |
| iptables        | IP Blocking                  |
| netstat         | Network Analysis             |
| base64          | Payload Decoding             |
| pandoc          | PDF Report Generation        |

---

# 📂 Project Structure

```bash
incident-response-lab/
│
├── windows_security.log
├── iocs.txt
├── incident_report.md
├── incident_report.pdf
└── README.md
```

---

# 🧪 Simulated Attack Scenario

The following suspicious activities were detected:

* Multiple failed login attempts
* Successful administrator login from suspicious IP
* Encoded PowerShell execution
* Malware deployment
* Reverse shell communication
* Unauthorized account creation
* Antivirus tampering

---

# 📜 Sample Log Entries

```log
2026-05-09 10:15:22 FAILED LOGIN user=admin src_ip=185.243.115.84
2026-05-09 10:16:01 FAILED LOGIN user=administrator src_ip=185.243.115.84
2026-05-09 10:17:33 SUCCESS LOGIN user=administrator src_ip=185.243.115.84
2026-05-09 10:18:04 POWERSHELL EXECUTION encoded_command=ZXZpbA==
2026-05-09 10:20:15 FILE MODIFIED C:\Windows\Temp\malware.exe
2026-05-09 10:21:30 OUTBOUND CONNECTION dst_ip=45.77.88.190 port=4444
2026-05-09 10:23:10 NEW USER CREATED user=hackeradmin
2026-05-09 10:25:55 ANTIVIRUS DISABLED
```

---

# 🔍 Log Analysis Commands

## Detect Failed Login Attempts

```bash
grep "FAILED LOGIN" windows_security.log
```

---

## Detect Successful Logins

```bash
grep "SUCCESS LOGIN" windows_security.log
```

---

## Detect PowerShell Execution

```bash
grep "POWERSHELL" windows_security.log
```

---

## Detect Malware Activity

```bash
grep "malware.exe" windows_security.log
```

---

## Detect Reverse Shell Connections

```bash
grep "OUTBOUND CONNECTION" windows_security.log
```

---

## Detect Unauthorized User Creation

```bash
grep "NEW USER CREATED" windows_security.log
```

---

# 🚨 Indicators of Compromise (IOCs)

## Suspicious IP Addresses

```txt
185.243.115.84
45.77.88.190
```

---

## Malicious File

```txt
C:\Windows\Temp\malware.exe
```

---

## Suspicious User Account

```txt
hackeradmin
```

---

# 🛡️ Containment Actions

## Block Malicious IP

```bash
sudo iptables -A INPUT -s 185.243.115.84 -j DROP
```

---

## View Active Connections

```bash
sudo netstat -antp
```

---

## Kill Suspicious Process

```bash
sudo kill -9 PID
```

---

## Quarantine Malware

```bash
mkdir quarantine
mv malware.exe quarantine/
```

---

# 📄 Report Generation

## Convert Markdown Report to PDF

```bash
sudo pacman -S pandoc
pandoc incident_report.md -o incident_report.pdf
```

---

# 📊 Findings

| Category         | Finding                   |
| ---------------- | ------------------------- |
| Attack Type      | Brute Force + Malware     |
| Persistence      | Unauthorized User Account |
| Malware Activity | Reverse Shell             |
| Defense Evasion  | Antivirus Disabled        |
| Severity         | HIGH                      |

---

# ✅ Recommendations

* Enable Multi-Factor Authentication (MFA)
* Restrict PowerShell execution policies
* Monitor failed login attempts
* Deploy SIEM solutions
* Use Endpoint Detection & Response (EDR)
* Keep systems updated

---

# 📌 Learning Outcomes

This project demonstrates:

* SOC analyst workflow
* Basic digital forensics
* Incident response lifecycle
* IOC identification
* Threat containment techniques
* Linux-based security operations

---

# 🚀 Future Improvements

* Integrate real SIEM logs
* Add automated IOC extraction
* Use ELK Stack or Splunk
* Add YARA rule detection
* Implement automated alerting

---

# 👨‍💻 Author

**Neeraj Upadhayay**
B.Tech CSE | Cybersecurity Enthusiast

# ⭐ Repository Purpose

This repository is created for:

* Cybersecurity practical work
* Academic submission
* GitHub portfolio
* SOC analyst practice
* Incident response learning

---

# 📜 License

This project is for educational and research purposes only.
